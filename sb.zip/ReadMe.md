# SB's Simulator

Unversidade de Brasilia
Instituto de Ciências Exatas
Departamento de Ciencia da Computaçao
Software Básico - 2/2019
Trabalho I - Simulador de Assembly Inventado
Porfessor: Bruno Macciavelo
Alunos: Gabriel Frutuoso Pereira Araujo
        Gustavo Sousa
Matrículas: 12/0050943
            1x/xxxxxxx
Turma: A
<!-- 
É fornecido um arquivo Makefile para auxiliar na comiplação do trabalho.
Para compilar digite no terminal:

    $ make

O compilador usado neste trabalho foi o GCC versão 5.0.4 utilizando C++11. O sistema operacional foi o Ubuntu 16.04 64 bits. Não foi utilizado nenhuma IDE neste trabalho, apenas um editor de texto (Sublime 3).

O Makefile fornecido é capaz de rodar os testes necessários de forma automatizada.
Para rodar os testes digite no terminal:

    $ make test_simulator -->


# Autores
Gabriel Frutuoso Pereira Araujo - Matricula 12/0050943
Gustavo Sousa - Matricula 1x/xxxxxxx
